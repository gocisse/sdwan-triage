// Initialize Reveal.js presentation
Reveal.initialize({
    // Display controls in the bottom right corner
    controls: true,
    
    // Display a presentation progress bar
    progress: true,
    
    // Display the page number of the current slide
    slideNumber: true,
    
    // Add the current slide number to the URL hash
    hash: true,
    
    // Push each slide change to the browser history
    history: true,
    
    // Enable keyboard shortcuts for navigation
    keyboard: true,
    
    // Enable the slide overview mode
    overview: true,
    
    // Vertical centering of slides
    center: true,
    
    // Enables touch navigation on devices with touch input
    touch: true,
    
    // Loop the presentation
    loop: false,
    
    // Change the presentation direction to be RTL
    rtl: false,
    
    // Randomizes the order of slides each time the presentation loads
    shuffle: false,
    
    // Turns fragments on and off globally
    fragments: true,
    
    // Flags whether to include the current fragment in the URL
    fragmentInURL: true,
    
    // Flags if the presentation is running in an embedded mode
    embedded: false,
    
    // Flags if we should show a help overlay when the questionmark key is pressed
    help: true,
    
    // Flags if speaker notes should be visible to all viewers
    showNotes: false,
    
    // Global override for autoplaying embedded media (video/audio/iframe)
    autoPlayMedia: null,
    
    // Number of milliseconds between automatically proceeding to the next slide
    autoSlide: 0,
    
    // Stop auto-sliding after user input
    autoSlideStoppable: true,
    
    // Use this method for navigation when auto-sliding
    autoSlideMethod: null,
    
    // Specify the average time in seconds that you think you will spend
    // presenting each slide
    defaultTiming: null,
    
    // Enable slide navigation via mouse wheel
    mouseWheel: false,
    
    // Hide cursor if inactive
    hideInactiveCursor: true,
    
    // Time before cursor is hidden (in ms)
    hideCursorTime: 5000,
    
    // Hides the address bar on mobile devices
    hideAddressBar: true,
    
    // Opens links in an iframe preview overlay
    previewLinks: false,
    
    // Transition style
    transition: 'slide', // none/fade/slide/convex/concave/zoom
    
    // Transition speed
    transitionSpeed: 'default', // default/fast/slow
    
    // Transition style for full page slide backgrounds
    backgroundTransition: 'fade', // none/fade/slide/convex/concave/zoom
    
    // Number of slides away from the current that are visible
    viewDistance: 3,
    
    // Number of slides away from the current that are visible on mobile
    mobileViewDistance: 2,
    
    // Parallax background image
    parallaxBackgroundImage: '',
    
    // Parallax background size
    parallaxBackgroundSize: '',
    
    // Number of pixels to move the parallax background per slide
    parallaxBackgroundHorizontal: null,
    parallaxBackgroundVertical: null,
    
    // The display mode that will be used to show slides
    display: 'block',
    
    // PDF export options
    pdfMaxPagesPerSlide: 1,
    pdfSeparateFragments: true,
    pdfPageHeightOffset: -1,
    
    // Plugin configuration
    plugins: []
});

// Custom keyboard shortcuts
Reveal.addKeyBinding({keyCode: 66, key: 'B', description: 'Toggle blackout'}, () => {
    document.body.style.backgroundColor = document.body.style.backgroundColor === 'black' ? '' : 'black';
});

// Add custom event listeners
Reveal.on('slidechanged', event => {
    // Log slide changes for analytics or debugging
    console.log(`Navigated to slide ${event.indexh + 1}`);
});

// Add animation to SVG elements when slide is shown
Reveal.on('slidechanged', event => {
    const currentSlide = event.currentSlide;
    const svgElements = currentSlide.querySelectorAll('svg line, svg circle, svg rect, svg path');
    
    svgElements.forEach((element, index) => {
        element.style.opacity = '0';
        setTimeout(() => {
            element.style.transition = 'opacity 0.5s ease-in-out';
            element.style.opacity = '1';
        }, index * 50);
    });
});

// Print mode detection
if (window.location.search.match(/print-pdf/gi)) {
    const links = document.querySelectorAll('link');
    links.forEach(link => {
        if (link.rel === 'stylesheet') {
            link.media = 'print';
        }
    });
}

// Add touch swipe support for mobile
let touchStartX = 0;
let touchEndX = 0;

document.addEventListener('touchstart', e => {
    touchStartX = e.changedTouches[0].screenX;
}, false);

document.addEventListener('touchend', e => {
    touchEndX = e.changedTouches[0].screenX;
    handleSwipe();
}, false);

function handleSwipe() {
    if (touchEndX < touchStartX - 50) {
        Reveal.next();
    }
    if (touchEndX > touchStartX + 50) {
        Reveal.prev();
    }
}

// Add fullscreen toggle with F key
document.addEventListener('keydown', e => {
    if (e.key === 'f' || e.key === 'F') {
        if (!document.fullscreenElement) {
            document.documentElement.requestFullscreen();
        } else {
            if (document.exitFullscreen) {
                document.exitFullscreen();
            }
        }
    }
});

// Add speaker notes toggle with S key (already built-in but enhanced)
document.addEventListener('keydown', e => {
    if (e.key === 's' || e.key === 'S') {
        // Open speaker view in new window
        Reveal.getConfig().showNotes = true;
    }
});

// Add slide timer
let slideStartTime = Date.now();
Reveal.on('slidechanged', () => {
    const timeSpent = Math.round((Date.now() - slideStartTime) / 1000);
    console.log(`Time spent on previous slide: ${timeSpent} seconds`);
    slideStartTime = Date.now();
});

// Add code syntax highlighting (basic)
document.addEventListener('DOMContentLoaded', () => {
    const codeBlocks = document.querySelectorAll('pre code');
    codeBlocks.forEach(block => {
        // Add line numbers
        const lines = block.textContent.split('\n');
        if (lines.length > 1) {
            block.classList.add('line-numbers');
        }
    });
});

// Add zoom functionality for diagrams
document.querySelectorAll('svg').forEach(svg => {
    svg.addEventListener('click', function(e) {
        if (e.target.tagName === 'svg' || e.target.closest('svg')) {
            this.classList.toggle('zoomed');
            if (this.classList.contains('zoomed')) {
                this.style.transform = 'scale(1.5)';
                this.style.transition = 'transform 0.3s ease';
                this.style.cursor = 'zoom-out';
            } else {
                this.style.transform = 'scale(1)';
                this.style.cursor = 'zoom-in';
            }
        }
    });
    svg.style.cursor = 'zoom-in';
});

// Add presentation timer in console
let presentationStartTime = Date.now();
setInterval(() => {
    const elapsed = Math.round((Date.now() - presentationStartTime) / 1000);
    const minutes = Math.floor(elapsed / 60);
    const seconds = elapsed % 60;
    console.log(`Presentation time: ${minutes}:${seconds.toString().padStart(2, '0')}`);
}, 60000); // Log every minute

// Add export to PDF helper
console.log('💡 Tip: To export as PDF, add ?print-pdf to the URL and use browser print');
console.log('💡 Tip: Press "F" for fullscreen, "ESC" for overview, "S" for speaker notes');
console.log('💡 Tip: Use arrow keys or swipe to navigate slides');

// Initialize presentation
console.log('🚀 Cisco SD-WAN Presentation loaded successfully!');
console.log(`📊 Total slides: ${Reveal.getTotalSlides()}`);
