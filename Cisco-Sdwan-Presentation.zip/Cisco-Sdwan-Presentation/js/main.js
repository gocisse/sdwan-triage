/* ============================================
   Cisco SD-WAN Presentation JavaScript
   Reveal.js initialization and custom functionality
   ============================================ */

// Initialize Reveal.js with proper configuration
Reveal.initialize({
    // Display dimensions
    width: 1200,
    height: 700,
    margin: 0.04,
    minScale: 0.2,
    maxScale: 2.0,
    center: true,
    
    // Behavior
    hash: true,
    slideNumber: 'c/t',
    transition: 'slide',
    backgroundTransition: 'fade',
    viewDistance: 3,
    
    // Controls
    controls: true,
    progress: true,
    overview: true,
    keyboard: true,
    touch: true,
    
    // Disable problematic features
    embedded: false,
    mouseWheel: false,
    hideAddressBar: true,
    
    // Additional settings
    history: true,
    help: true,
    showSlideNumber: 'all',
    autoSlide: 0,
    autoSlideStoppable: true,
    hideInactiveCursor: true,
    hideCursorTime: 5000,
    previewLinks: false,
    
    // Fragments
    fragments: true,
    
    // PDF export settings
    pdfMaxPagesPerSlide: 1,
    pdfSeparateFragments: true
});

// ============================================
// Copy Button Functionality
// ============================================
function initCopyButtons() {
    document.querySelectorAll('pre code').forEach(function(codeBlock) {
        // Skip if already has a copy button
        if (codeBlock.parentNode.querySelector('.copy-btn')) return;
        
        const button = document.createElement('button');
        button.className = 'copy-btn';
        button.textContent = 'Copy';
        
        button.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            
            const text = codeBlock.textContent;
            
            navigator.clipboard.writeText(text).then(function() {
                button.textContent = 'Copied!';
                button.classList.add('copied');
                
                setTimeout(function() {
                    button.textContent = 'Copy';
                    button.classList.remove('copied');
                }, 2000);
            }).catch(function(err) {
                console.error('Failed to copy:', err);
                button.textContent = 'Error';
                
                setTimeout(function() {
                    button.textContent = 'Copy';
                }, 2000);
            });
        });
        
        // Make parent position relative for absolute positioning
        codeBlock.parentNode.style.position = 'relative';
        codeBlock.parentNode.appendChild(button);
    });
}

// ============================================
// Custom Keyboard Shortcuts
// ============================================
function initKeyboardShortcuts() {
    document.addEventListener('keydown', function(e) {
        // F key - Toggle fullscreen
        if (e.key === 'f' || e.key === 'F') {
            if (!e.ctrlKey && !e.metaKey && !e.altKey) {
                e.preventDefault();
                toggleFullscreen();
            }
        }
        
        // B key - Toggle blackout
        if (e.key === 'b' || e.key === 'B') {
            if (!e.ctrlKey && !e.metaKey && !e.altKey) {
                // Reveal.js handles this natively
            }
        }
        
        // P key - Print/PDF mode hint
        if (e.key === 'p' || e.key === 'P') {
            if (e.ctrlKey || e.metaKey) {
                // Let browser handle print
            }
        }
    });
}

// ============================================
// Fullscreen Toggle
// ============================================
function toggleFullscreen() {
    if (!document.fullscreenElement && 
        !document.webkitFullscreenElement && 
        !document.mozFullScreenElement) {
        // Enter fullscreen
        const elem = document.documentElement;
        if (elem.requestFullscreen) {
            elem.requestFullscreen();
        } else if (elem.webkitRequestFullscreen) {
            elem.webkitRequestFullscreen();
        } else if (elem.mozRequestFullScreen) {
            elem.mozRequestFullScreen();
        }
    } else {
        // Exit fullscreen
        if (document.exitFullscreen) {
            document.exitFullscreen();
        } else if (document.webkitExitFullscreen) {
            document.webkitExitFullscreen();
        } else if (document.mozCancelFullScreen) {
            document.mozCancelFullScreen();
        }
    }
}

// ============================================
// Touch/Swipe Handling Enhancement
// ============================================
function initTouchHandling() {
    let touchStartX = 0;
    let touchStartY = 0;
    let touchEndX = 0;
    let touchEndY = 0;
    
    const minSwipeDistance = 50;
    
    document.addEventListener('touchstart', function(e) {
        touchStartX = e.changedTouches[0].screenX;
        touchStartY = e.changedTouches[0].screenY;
    }, { passive: true });
    
    document.addEventListener('touchend', function(e) {
        touchEndX = e.changedTouches[0].screenX;
        touchEndY = e.changedTouches[0].screenY;
        handleSwipe();
    }, { passive: true });
    
    function handleSwipe() {
        const deltaX = touchEndX - touchStartX;
        const deltaY = touchEndY - touchStartY;
        
        // Only handle if horizontal swipe is dominant
        if (Math.abs(deltaX) > Math.abs(deltaY) && Math.abs(deltaX) > minSwipeDistance) {
            if (deltaX < 0) {
                // Swipe left - next slide
                Reveal.next();
            } else {
                // Swipe right - previous slide
                Reveal.prev();
            }
        }
        // Vertical swipes for vertical slides
        else if (Math.abs(deltaY) > Math.abs(deltaX) && Math.abs(deltaY) > minSwipeDistance) {
            if (deltaY < 0) {
                // Swipe up - next vertical slide
                Reveal.down();
            } else {
                // Swipe down - previous vertical slide
                Reveal.up();
            }
        }
    }
}

// ============================================
// Slide Change Handler
// ============================================
function initSlideChangeHandler() {
    Reveal.on('slidechanged', function(event) {
        // Log slide change for debugging
        console.log('Slide changed:', event.indexh + 1, '/', Reveal.getTotalSlides());
        
        // Re-initialize copy buttons for new slide content
        initCopyButtons();
    });
}

// ============================================
// Ready Handler
// ============================================
Reveal.on('ready', function(event) {
    console.log('✅ Cisco SD-WAN Presentation loaded');
    console.log('📊 Total slides:', Reveal.getTotalSlides());
    console.log('💡 Press F for fullscreen, O for overview, ESC to exit');
    
    // Initialize all features
    initCopyButtons();
    initKeyboardShortcuts();
    initTouchHandling();
    initSlideChangeHandler();
});

// ============================================
// Window Resize Handler
// ============================================
window.addEventListener('resize', function() {
    // Debounce resize events
    clearTimeout(window.resizeTimeout);
    window.resizeTimeout = setTimeout(function() {
        Reveal.layout();
    }, 100);
});

// ============================================
// Orientation Change Handler (Mobile)
// ============================================
window.addEventListener('orientationchange', function() {
    setTimeout(function() {
        Reveal.layout();
        Reveal.sync();
    }, 300);
});

// ============================================
// Print Detection
// ============================================
window.addEventListener('beforeprint', function() {
    console.log('📄 Preparing for print...');
});

window.addEventListener('afterprint', function() {
    console.log('📄 Print complete');
});

// ============================================
// Help Text (shown in console)
// ============================================
console.log(`
╔════════════════════════════════════════════╗
║  Cisco SD-WAN Presentation Controls        ║
╠════════════════════════════════════════════╣
║  → / Space    Next slide                   ║
║  ←            Previous slide               ║
║  ↓            Next vertical slide          ║
║  ↑            Previous vertical slide      ║
║  F            Toggle fullscreen            ║
║  O            Overview mode                ║
║  ESC          Exit overview/fullscreen     ║
║  B            Blackout screen              ║
║  S            Speaker notes (if enabled)   ║
║  ?            Show help                    ║
╚════════════════════════════════════════════╝
`);
